import os
import random ,string

logo = '''▒██   ██▒▓█████▄  ███▄ ▄███▓ ▄▄▄       ██▀███  
▒▒ █ █ ▒░▒██▀ ██▌▓██▒▀█▀ ██▒▒████▄    ▓██ ▒ ██▒
░░  █   ░░██   █▌▓██    ▓██░▒██  ▀█▄  ▓██ ░▄█ ▒
 ░ █ █ ▒ ░▓█▄   ▌▒██    ▒██ ░██▄▄▄▄██ ▒██▀▀█▄  
▒██▒ ▒██▒░▒████▓ ▒██▒   ░██▒ ▓█   ▓██▒░██▓ ▒██▒
▒▒ ░ ░▓ ░ ▒▒▓  ▒ ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒▓ ░▒▓░
░░   ░▒ ░ ░ ▒  ▒ ░  ░      ░  ▒   ▒▒ ░  ░▒ ░ ▒░
 ░    ░   ░ ░  ░ ░      ░     ░   ▒     ░░   ░ 
 ░    ░     ░           ░         ░  ░   ░     
          ░                                    

c0ded by: XD2MAR haCker 
snapchat: d2mar
        '''


os.system('cls' if os.name == 'nt' else 'clear')
print(logo)

def res(length):
    let = string.ascii_lowercase + string.digits
    result = ''.join(random.choice(let) for i in range(length))
    print(result)
    with open('xd2mar.txt','a+') as f:
        f.write(result+'\n')

for i in range(1,5000000):
    res(40)
